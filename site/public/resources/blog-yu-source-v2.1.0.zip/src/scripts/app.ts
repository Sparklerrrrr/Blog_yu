/**
 * 全站客户端交互（唯一入口）
 * 由 BaseLayout 通过 <script src> 引入，Astro 会统一打包压缩。
 * 职责：下拉菜单 / 移动菜单 / 搜索面板 / 主题切换 / 音乐播放器 /
 *       公告关闭 / 滚动监听 / 入场动效 / 数字动画 / 3D 倾斜 / 复制校验。
 */

      // ===== 全局交互（事件委托 + astro:page-load，页面切换后依然有效） =====
      const q = <T extends HTMLElement>(sel: string) => document.querySelector<T>(sel);

  // ---- 滚动状态：顶栏玻璃 / 顶部进度条 / 阅读进度环（导航固定常驻，不随滚动隐藏） ----
  const syncScroll = () => {
    const nav = q('#site-nav');
    const y = window.scrollY;
    nav?.classList.toggle('is-scrolled', y > 24);
    const bar = q('#progress-bar');
    if (bar) {
      const doc = document.documentElement;
      const max = doc.scrollHeight - doc.clientHeight;
      bar.style.width = `${max > 0 ? (window.scrollY / max) * 100 : 0}%`;
    }
    const ring = q('#progress-ring');
    if (ring) {
      const doc = document.documentElement;
      const max = doc.scrollHeight - doc.clientHeight;
      const p = max > 0 ? Math.min(100, (window.scrollY / max) * 100) : 0;
      ring.classList.toggle('is-visible', window.scrollY > 100);
      ring.querySelector('.bar')?.setAttribute('stroke-dasharray', `${p.toFixed(1)} 100`);
      ring.setAttribute('aria-label', `返回顶部（已阅读 ${Math.round(p)}%）`);
    }

    // Hero 视差：滚动时内容缓速上移并淡出（首页）
    const hero = q<HTMLElement>('.hero');
    if (hero && !reduceMotion) {
      const vh = window.innerHeight || 1;
      const p = Math.min(1, y / (vh * 0.9));
      const content = hero.querySelector<HTMLElement>('.hero-content');
      if (content) {
        content.style.transform = `translateY(${(y * 0.22).toFixed(1)}px)`;
        content.style.opacity = Math.max(0, 1 - p * 1.15).toFixed(3);
      }
      const wm = hero.querySelector<HTMLElement>('.watermark');
      if (wm) wm.style.transform = `translateY(${(y * 0.1).toFixed(1)}px)`;
      const hint = hero.querySelector<HTMLElement>('.scroll-hint');
      if (hint) hint.style.opacity = Math.max(0, 1 - p * 2.4).toFixed(3);
    }
  };
  window.addEventListener('scroll', syncScroll, { passive: true });
  window.addEventListener('resize', syncScroll);

  // ---- 点击：下拉 / 移动菜单 / 主题切换 / 进度环回顶（全部事件委托） ----
  document.addEventListener('click', (e) => {
    const t = e.target as HTMLElement;

    // 下拉菜单：点哪个开哪个；点外部关闭全部
    const closeAllDropdowns = () => {
      document.querySelectorAll('[data-dropdown].open').forEach((d) => {
        d.classList.remove('open');
        d.querySelector('[data-dropdown-trigger]')?.setAttribute('aria-expanded', 'false');
      });
    };
    const triggerEl = t.closest('[data-dropdown-trigger]');
    const dropdown = triggerEl?.closest('[data-dropdown]');
    if (triggerEl && dropdown) {
      const open = !dropdown.classList.contains('open');
      closeAllDropdowns();
      dropdown.classList.toggle('open', open);
      dropdown
        .querySelector('[data-dropdown-trigger]')
        ?.setAttribute('aria-expanded', String(open));
    } else if (!t.closest('[data-dropdown]')) {
      closeAllDropdowns();
    }

    // 移动端菜单
    const menuBtn = t.closest('#menu-toggle');
    if (menuBtn) {
      const menu = q('#mobile-menu');
      const open = menu?.hasAttribute('hidden') ?? true;
      menu?.toggleAttribute('hidden', !open);
      menuBtn.setAttribute('aria-expanded', String(open));
      menuBtn.setAttribute('aria-label', open ? '关闭菜单' : '打开菜单');
    } else if (t.closest('#mobile-menu a')) {
      q('#mobile-menu')?.setAttribute('hidden', '');
      q('#menu-toggle')?.setAttribute('aria-expanded', 'false');
    }

    // 明暗主题切换（按钮可能同时存在于侧边栏与移动顶栏）
    if (t.closest('.theme-toggle')) {
      const next = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
      const applyTheme = () => {
        document.documentElement.dataset.theme = next;
        try {
          localStorage.setItem('blog-theme', next);
        } catch {
          /* 隐私模式下忽略 */
        }
        syncThemeIcon();
      };
      // 支持 View Transition 的浏览器：明暗切换带淡入淡出过渡；否则直接切换
      const d = document as Document & { startViewTransition?: (cb: () => void) => unknown };
      if (typeof d.startViewTransition === 'function' && !reduceMotion) {
        d.startViewTransition(applyTheme);
      } else {
        applyTheme();
      }
    }

    // 阅读进度环：回到顶部
    if (t.closest('#progress-ring')) {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    // 搜索面板（清风博客式悬浮玻璃面板）
    const searchPanel = q('#search-panel');
    if (t.closest('#search-toggle')) {
      if (searchPanel) {
        if (searchPanel.classList.contains('open')) {
          searchPanel.classList.remove('open');
        } else {
          openSearch();
        }
      }
    } else if (searchPanel?.classList.contains('open') && !t.closest('#search-panel')) {
      searchPanel.classList.remove('open');
    }

    // 悬浮音乐播放器：音符按钮开合弹窗
    const musicPop = q('#music-popup');
    if (t.closest('#music-toggle')) {
      if (musicPop) musicPop.classList.toggle('open', !musicPop.classList.contains('open'));
    } else if (musicPop?.classList.contains('open') && !t.closest('#music-popup')) {
      musicPop.classList.remove('open');
    }

    // 播放器控件（事件委托：元素持久化/重建后依然有效）
    if (t.closest('#player-toggle')) {
      const audio = playerState.audio;
      if (audio) {
        if (audio.paused) {
          audio.muted = false; // 点播放永远出声
          audio.play().catch(() => {});
        } else {
          audio.pause();
        }
      }
    } else if (t.closest('#player-next')) {
      loadTrack(playerState.index + 1);
    } else if (t.closest('#player-prev')) {
      loadTrack(playerState.index - 1);
    } else if (t.closest('#player-repeat')) {
      const modes = ['list', 'one', 'shuffle'] as const;
      playerState.mode = modes[(modes.indexOf(playerState.mode) + 1) % 3];
      const btn = t.closest('#player-repeat');
      if (btn) {
        btn.innerHTML =
          playerState.mode === 'list'
            ? playerIcons.repeat
            : playerState.mode === 'one'
              ? playerIcons.repeatOne
              : playerIcons.shuffle;
        btn.setAttribute(
          'title',
          playerState.mode === 'list' ? '列表循环' : playerState.mode === 'one' ? '单曲循环' : '随机播放'
        );
      }
    } else if (t.closest('#player-list')) {
      const list = q('#player-playlist');
      if (list) {
        const open = list.hasAttribute('hidden');
        list.toggleAttribute('hidden', !open);
        t.closest('#player-list')?.setAttribute('aria-label', open ? '收起播放列表' : '播放列表');
      }
    } else if (t.closest('.playlist-item')) {
      const item = t.closest('.playlist-item') as HTMLElement;
      loadTrack(parseInt(item.dataset.index ?? '0', 10));
    } else if (t.closest('#player-volume')) {
      const bar = t.closest('#player-volume') as HTMLElement;
      const r = bar.getBoundingClientRect();
      setVol((e.clientX - r.left) / r.width);
    } else if (t.closest('#player-mute')) {
      const audio = playerState.audio;
      if (audio) {
        audio.muted = !audio.muted;
        if (audio.muted) userMutedByClick = true; // 用户手动静音后不再自动解除
        const btn = t.closest('#player-mute');
        if (btn)
          btn.innerHTML = audio.muted || audio.volume === 0 ? playerIcons.volMute : playerIcons.volHigh;
      }
    }

    // 品牌 Logo：点击转圈小彩蛋
    if (t.closest('.nav-brand')) {
      const logo = q('.nav-logo');
      if (logo) {
        logo.classList.remove('is-spin');
        void logo.offsetWidth;
        logo.classList.add('is-spin');
        logo.addEventListener('animationend', () => logo.classList.remove('is-spin'), { once: true });
      }
    }

    // 板块切换（ak.hypergryph.com 式横向过渡）：点导航锚点后，
    // 重放目标板块面板的横向滑入动画，让每次切换都有横滑效果
    const anchor = t.closest('a[href*="#"]');
    const hash = anchor?.getAttribute('href')?.split('#')[1];
    if (hash) {
      const panel = document.getElementById(hash)?.querySelector('.panel.reveal-x');
      if (panel) {
        panel.classList.remove('is-in');
        void panel.offsetWidth; // 强制 reflow，让动画重新触发
        panel.classList.add('is-in');
      }
    }
  });

  // 搜索输入实时过滤（事件委托）
  document.addEventListener('input', (e) => {
    const input = e.target as HTMLInputElement | null;
    if (!input || input.id !== 'search-input') return;
    const list = q('#search-results');
    const empty = q('#search-empty');
    if (!list) return;
    const kw = (input.value ?? '').trim().toLowerCase();
    let n = 0;
    list.querySelectorAll<HTMLElement>('a').forEach((a) => {
      const hay = (a.dataset.hay ?? '').toLowerCase();
      const show = !kw || hay.includes(kw);
      a.style.display = show ? '' : 'none';
      if (show) n += 1;
      else a.classList.remove('is-selected');
    });
    if (empty) empty.hidden = n > 0;
  });

  // ---- 搜索面板键盘辅助：可见结果 / 移动选中 / 打开并聚焦 ----
  const visibleResults = () =>
    Array.from(document.querySelectorAll<HTMLAnchorElement>('#search-results .search-result')).filter(
      (a) => a.style.display !== 'none'
    );
  const moveSearchSel = (dir: number) => {
    const list = visibleResults();
    if (list.length === 0) return;
    const idx = list.findIndex((a) => a.classList.contains('is-selected'));
    list.forEach((a) => a.classList.remove('is-selected'));
    const base = idx === -1 ? (dir > 0 ? -1 : 0) : idx;
    const next = (base + dir + list.length) % list.length;
    list[next].classList.add('is-selected');
    list[next].scrollIntoView({ block: 'nearest' });
  };
  const openSearch = () => {
    const panel = q('#search-panel');
    if (!panel) return;
    panel.classList.add('open');
    const inp = q<HTMLInputElement>('#search-panel input');
    inp?.focus();
    inp?.select();
  };

  document.addEventListener('keydown', (e) => {
    const target = e.target as HTMLElement;

    if (e.key === 'Escape') {
      document.querySelectorAll('[data-dropdown].open').forEach((d) => {
        d.classList.remove('open');
        d.querySelector('[data-dropdown-trigger]')?.setAttribute('aria-expanded', 'false');
      });
      q('#mobile-menu')?.setAttribute('hidden', '');
      q('#menu-toggle')?.setAttribute('aria-expanded', 'false');
      q('#search-panel')?.classList.remove('open');
      return;
    }

    // 快捷键：/ 或 Ctrl/Cmd+K 打开并聚焦搜索（输入框内不劫持）
    const typing = target.matches('input, textarea, select, [contenteditable="true"]');
    if (!typing && (e.key === '/' || ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k'))) {
      e.preventDefault();
      openSearch();
      return;
    }

    // 搜索面板内：↑↓ 选择结果，Enter 打开
    if (target.id === 'search-input') {
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        moveSearchSel(e.key === 'ArrowDown' ? 1 : -1);
      } else if (e.key === 'Enter') {
        const list = visibleResults();
        const sel = list.find((a) => a.classList.contains('is-selected')) ?? list[0];
        if (sel) {
          e.preventDefault();
          sel.click();
        }
      }
    }
  });

  // ---- 主题切换按钮图标（nav-icon 类保证 18px 尺寸） ----
  const moonIcon =
    '<svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M20.5 14.5A8.5 8.5 0 0 1 9.5 3.5a8.5 8.5 0 1 0 11 11z"/></svg>';
  const sunIcon =
    '<svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="4.2"/><path d="M12 2.8v2.2M12 19v2.2M2.8 12H5M19 12h2.2M5.2 5.2l1.6 1.6M17.2 17.2l1.6 1.6M18.8 5.2l-1.6 1.6M6.8 17.2l-1.6 1.6"/></svg>';
  function syncThemeIcon() {
    // 只替换按钮内的 svg 图标，保留「亮暗」文字标签
    document.querySelectorAll('.theme-toggle svg').forEach((el) => {
      el.outerHTML = document.documentElement.dataset.theme === 'dark' ? sunIcon : moonIcon;
    });
  }
  syncThemeIcon();

  // ---- 滚动显现（IntersectionObserver；导航到新页面后重新扫描） ----
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  let io: IntersectionObserver | null = null;

  // 数字滚动：元素进入视口后从 0 缓动到目标值（保留后缀与千分位格式，支持小数）
  const animateCount = (el: HTMLElement) => {
    if (reduceMotion) return;
    const raw = el.textContent?.trim() ?? '';
    const m = raw.match(/^([\d,]+(?:\.\d+)?)(.*)$/);
    if (!m) return;
    const target = parseFloat(m[1].replace(/,/g, ''));
    if (!isFinite(target) || target <= 0) return;
    const suffix = m[2];
    const decimals = (m[1].split('.')[1] ?? '').length;
    const useComma = m[1].includes(',');
    const fmt = (v: number) =>
      decimals > 0
        ? v.toFixed(decimals)
        : useComma
          ? Math.round(v).toLocaleString()
          : String(Math.round(v));
    const t0 = performance.now();
    const dur = 900;
    const step = (now: number) => {
      const p = Math.min(1, (now - t0) / dur);
      const eased = 1 - Math.pow(1 - p, 3);
      el.textContent = fmt(target * eased) + suffix;
      if (p < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  };

  const observeReveals = () => {
    io?.disconnect();
    if (reduceMotion) {
      document.querySelectorAll('.reveal, .reveal-x').forEach((el) => el.classList.add('is-in'));
      return;
    }
    io = new IntersectionObserver(
      (entries) => {
        entries.forEach((en) => {
          if (en.isIntersecting) {
            en.target.classList.add('is-in');
            if (en.target instanceof HTMLElement && en.target.hasAttribute('data-count')) {
              animateCount(en.target);
            }
            io?.unobserve(en.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: '0px 0px -32px 0px' }
    );
    document
      .querySelectorAll('.reveal:not(.is-in), .reveal-x:not(.is-in), [data-count]')
      .forEach((el) => io?.observe(el));
  };

  // ---- 板块滚动高亮（scrollspy，ak.hypergryph.com 的导航跟随方式） ----
  // 每个导航项带 data-spy="区块id"，滚动到对应区块时高亮该项
  let spyIo: IntersectionObserver | null = null;
  const bindSpy = () => {
    const items = Array.from(document.querySelectorAll<HTMLElement>('.nav-item[data-spy]'));
    if (items.length === 0) return;
    spyIo?.disconnect();
    // 视口中带（中部 45% 判定带）确定当前区块
    spyIo = new IntersectionObserver(
      (entries) => {
        entries.forEach((en) => {
          if (!en.isIntersecting) return;
          const id = (en.target as HTMLElement).id;
          items.forEach((item) => {
            item.classList.toggle('is-spy-active', item.dataset.spy === id);
          });
        });
      },
      { rootMargin: '-35% 0px -55% 0px', threshold: 0 }
    );
    items.forEach((item) => {
      const target = document.getElementById(item.dataset.spy ?? '');
      if (target) spyIo?.observe(target);
    });
  };

  // ---- 卡片 3D 倾斜（复刻 deepseek.com/harness：perspective(800px) + 双轴最多 3° +
  //      scale(1.01)；跟随过渡 transform 0.1s ease-out，离开回正 0.4s ease-out；
  //      仅鼠标/触控板等精细指针，减弱动效偏好时关闭）
  //      保留本站卡片的 hover 上浮 translateY(-6px)，其余参数与 harness 一致 ----
  const canTilt =
    !reduceMotion && window.matchMedia('(hover: hover) and (pointer: fine)').matches;
  // 内联 transition 会整体覆盖 CSS 过渡，因此把卡片的描边/阴影过渡一并带上，避免 snap
  const TILT_FAST =
    'transform 0.1s ease-out, border-color var(--dur-1) var(--ease), border-left-width var(--dur-1) var(--ease), box-shadow var(--dur-1) var(--ease)';
  const TILT_SLOW =
    'transform 0.4s ease-out, border-color var(--dur-1) var(--ease), border-left-width var(--dur-1) var(--ease), box-shadow var(--dur-1) var(--ease)';
  const bindTilt = () => {
    if (!canTilt) return;
    document.querySelectorAll<HTMLElement>('[data-tilt]').forEach((card) => {
      if (card.dataset.tiltBound) return;
      card.dataset.tiltBound = '1';
      let raf = 0;
      card.addEventListener('pointermove', (e) => {
        const r = card.getBoundingClientRect();
        if (r.width === 0 || r.height === 0) return;
        // harness 公式：rotateX = (cy - y)/cy * 3，rotateY = (x - cx)/cx * 3
        const rx = ((r.height / 2 - (e.clientY - r.top)) / (r.height / 2)) * 3;
        const ry = ((e.clientX - r.left) - r.width / 2) / (r.width / 2) * 3;
        cancelAnimationFrame(raf);
        raf = requestAnimationFrame(() => {
          card.style.transition = TILT_FAST;
          card.style.transform =
            `translateY(-6px) perspective(800px) rotateX(${rx.toFixed(2)}deg) rotateY(${ry.toFixed(2)}deg) scale(1.01)`;
        });
      });
      card.addEventListener('pointerleave', () => {
        cancelAnimationFrame(raf);
        card.style.transition = TILT_SLOW;
        card.style.transform = '';
      });
    });
  };

  // ---- 小版块「令牌」反光 + 小幅 3D 倾斜（仅精细指针 + 非减弱动效） ----
  // 指针移动 → 小卡片像令牌一样随指针小幅倾斜（perspective(1000px)、双轴最多 2°），
  // 表面反光带随倾斜同步滑动（--gx 驱动 background-position-x）——
  // 反光是卡片自身的属性，不是跟随鼠标的光斑；滚动/缩放时按最新卡片位置重画
  // 内联 transition 会整体覆盖 CSS 过渡，这里把卡片/面板用到的过渡属性全部带上，
  // 避免悬停描边/阴影/公告收起等效果 snap
  const REFLECT_FAST =
    'transform 0.15s ease-out, box-shadow 0.3s var(--ease), border-color 0.3s var(--ease), border-left-width 0.3s var(--ease), background-color 0.3s var(--ease), width 0.55s cubic-bezier(0.16, 1, 0.3, 1), max-height 0.55s cubic-bezier(0.16, 1, 0.3, 1), padding 0.55s cubic-bezier(0.16, 1, 0.3, 1), margin 0.55s cubic-bezier(0.16, 1, 0.3, 1), opacity 0.25s ease';
  const REFLECT_SLOW =
    'transform 0.5s ease-out, box-shadow 0.3s var(--ease), border-color 0.3s var(--ease), border-left-width 0.3s var(--ease), background-color 0.3s var(--ease), width 0.55s cubic-bezier(0.16, 1, 0.3, 1), max-height 0.55s cubic-bezier(0.16, 1, 0.3, 1), padding 0.55s cubic-bezier(0.16, 1, 0.3, 1), margin 0.55s cubic-bezier(0.16, 1, 0.3, 1), opacity 0.25s ease';

  const paintReflection = (
    el: HTMLElement,
    x: number,
    y: number,
    withTilt: boolean,
    tiltX = x,
    tiltY = y,
    hx = x,
    hy = y
  ) => {
    const r = el.getBoundingClientRect();
    if (r.width === 0 || r.height === 0) return;
    if (el.classList.contains('spot-corners')) {
      // 边缘漏光：指针方向映射为面板边界外约 36px 的虚拟光源，
      // 光从对应边缘/角落漏入并向四周减弱；居中时回到面板中央只剩浅浅一点
      const cxr = r.width / 2;
      const cyr = r.height / 2;
      const vx = x - r.left - cxr;
      const vy = y - r.top - cyr;
      const len = Math.hypot(vx, vy);
      let mx = cxr;
      let my = cyr;
      let mag = 0;
      if (len >= 1) {
        const ux = vx / len;
        const uy = vy / len;
        // 光源沿中心→指针方向连续外推：len=0 时在面板中心，
        // 越靠边越滑向边界外 36px（len=t 时到最外）——中心到边缘全程无跳变
        const t = Math.min(cxr / Math.abs(ux || 1e-6), cyr / Math.abs(uy || 1e-6));
        const d = (len / t) * (t + 36);
        mx = cxr + ux * d;
        my = cyr + uy * d;
        mag = Math.min(1, len / Math.max(cxr, cyr));
      }
      // smoothstep 缓动：越接近边缘亮度爬升越缓，中间段过渡更柔
      const magE = mag * mag * (3 - 2 * mag);
      el.style.setProperty('--mx', `${mx.toFixed(1)}px`);
      el.style.setProperty('--my', `${my.toFixed(1)}px`);
      el.style.setProperty('--lx', (0.35 + 0.65 * magE).toFixed(3));
      // 环境光晕：慢半拍的虚拟光源（hx/hy 独立投影），光在身后慢慢化开
      const hvx = hx - r.left - cxr;
      const hvy = hy - r.top - cyr;
      const hlen = Math.hypot(hvx, hvy);
      if (hlen >= 1) {
        const hux = hvx / hlen;
        const huy = hvy / hlen;
        const ht = Math.min(cxr / Math.abs(hux || 1e-6), cyr / Math.abs(huy || 1e-6));
        const hd = (hlen / ht) * (ht + 36);
        el.style.setProperty('--mx2', `${(cxr + hux * hd).toFixed(1)}px`);
        el.style.setProperty('--my2', `${(cyr + huy * hd).toFixed(1)}px`);
      } else {
        el.style.setProperty('--mx2', `${cxr}px`);
        el.style.setProperty('--my2', `${cyr}px`);
      }
      // 光斑朝向跟随指针主方向：上下边主导 → 横向椭圆（沿边铺开、纵向衰减）；
      // 左右边主导 → 纵向椭圆（沿边铺开、横向衰减）；按方向连续插值，角落自然过渡。
      // 尺寸随板块大小自适应：沿边铺到接近整条边、向板内衰减到接近对边 ——
      // 大板块也有完整的光渐变，小卡片保持紧凑不糊成一团
      const nx = vx / (cxr || 1);
      const ny = vy / (cyr || 1);
      const axn = Math.abs(nx);
      const ayn = Math.abs(ny);
      const k = len >= 1 ? axn / (axn + ayn || 1) : 0;
      const lerp = (a: number, b: number, q: number) => a + (b - a) * q;
      const clampR = (v: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, v));
      const ex0 = clampR(r.width * 0.95, 260, 1000);  // 上下边：横向铺开
      const ex1 = clampR(r.width * 0.85, 200, 1000);  // 左右边：横向衰减
      const ey0 = clampR(r.height * 0.85, 200, 1000); // 上下边：纵向衰减
      const ey1 = clampR(r.height * 0.95, 260, 1000); // 左右边：纵向铺开
      el.style.setProperty('--erx', `${lerp(ex0, ex1, k).toFixed(0)}px`);
      el.style.setProperty('--ery', `${lerp(ey0, ey1, k).toFixed(0)}px`);
      const ax0 = clampR(r.width * 1.35, 380, 1500);  // 环境光晕同逻辑放大
      const ax1 = clampR(r.width * 1.15, 320, 1400);
      const ay0 = clampR(r.height * 1.15, 260, 1100);
      const ay1 = clampR(r.height * 1.35, 320, 1300);
      el.style.setProperty('--eax', `${lerp(ax0, ax1, k).toFixed(0)}px`);
      el.style.setProperty('--eay', `${lerp(ay0, ay1, k).toFixed(0)}px`);
    } else {
      // 反光带滑动：与倾斜同向，最大 ±20% 卡片宽
      el.style.setProperty('--gx', `${((x - r.left - r.width / 2) * 0.4).toFixed(1)}px`);
    }
    if (!withTilt) return;
    // 令牌式倾斜（harness 公式，幅度收小到 2°；.card 类保留 hover 上浮）
    // 使用轻微速度外推后的预测坐标，面板像在「迎接」指针
    const clamp2 = (v: number) => Math.max(-2, Math.min(2, v));
    const rx = clamp2(((r.height / 2 - (tiltY - r.top)) / (r.height / 2)) * 2);
    const ry = clamp2(((tiltX - r.left) - r.width / 2) / (r.width / 2) * 2);
    const lift = el.classList.contains('resource-card')
      ? 'translateY(-4px) '
      : el.classList.contains('card')
        ? 'translateY(-6px) '
        : el.classList.contains('bangumi-card')
          ? 'translateY(-4px) '
          : el.classList.contains('friend-card')
            ? 'translateY(-3px) '
            : '';
    el.style.transition = REFLECT_FAST;
    el.style.transform = `${lift}perspective(1000px) rotateX(${rx.toFixed(2)}deg) rotateY(${ry.toFixed(2)}deg)`;
  };
  const refreshReflection = () => {
    const el = document.querySelector<HTMLElement>('.spot-card:hover');
    if (!el) return;
    const x = parseFloat(el.dataset.spotX ?? '');
    const y = parseFloat(el.dataset.spotY ?? '');
    if (isFinite(x) && isFinite(y)) paintReflection(el, x, y, el.dataset.spotTilt === '1');
  };
  // 全局滚动/缩放监听只挂一次（window 标记防 HMR/重复执行累积）
  const wSpot = window as unknown as { __spotGlowBound?: boolean };
  if (!wSpot.__spotGlowBound) {
    wSpot.__spotGlowBound = true;
    window.addEventListener('scroll', refreshReflection, { passive: true });
    window.addEventListener('resize', refreshReflection);
  }

  const bindPanelReflection = () => {
    if (!canTilt) return;

    // 绑定单个小版块：令牌反光 + 倾斜。
    // 已带 data-tilt 的卡片（文章卡/分类块/账号卡/联系卡）保持既有 harness 倾斜，这里只驱动反光带
    const bindOne = (el: HTMLElement) => {
      if (el.dataset.spotBound) return;
      el.dataset.spotBound = '1';
      el.classList.add('spot-card');
      const hasTilt = el.hasAttribute('data-tilt');
      if (!hasTilt) el.dataset.spotTilt = '1';
      let raf = 0;
      // 边缘漏光专属：坐标做指数平滑（约 90ms 时间常数），
      // 光斑位置/强度/朝向与面板倾斜共用同一份平滑坐标 —— 过渡连贯不跳变
      const corners = el.classList.contains('spot-corners');
      const sm = {
        tx: 0, ty: 0, cx: 0, cy: 0, hx: 0, hy: 0, px: 0, py: 0, vx: 0, vy: 0,
        last: 0, on: false, raf: 0,
      };
      const stepSmooth = () => {
        const now = performance.now();
        const dt = Math.min(64, now - sm.last || 16);
        sm.last = now;
        // 自适应时间常数：静止/慢速时更跟手（80ms），快速甩动时更飘逸（最长约 150ms）
        const trail = Math.hypot(sm.tx - sm.cx, sm.ty - sm.cy);
        const tau = 80 + Math.min(70, trail * 0.08);
        const e = 1 - Math.exp(-dt / tau);
        sm.cx += (sm.tx - sm.cx) * e;
        sm.cy += (sm.ty - sm.cy) * e;
        // 光晕：更慢的时间常数（tau+55ms），像光在身后慢慢化开
        const eh = 1 - Math.exp(-dt / (tau + 55));
        sm.hx += (sm.tx - sm.hx) * eh;
        sm.hy += (sm.ty - sm.hy) * eh;
        // 倾斜预测：按近几帧速度外推 3 帧，面板像在迎接指针
        sm.vx = sm.cx - sm.px;
        sm.vy = sm.cy - sm.py;
        sm.px = sm.cx;
        sm.py = sm.cy;
        const predX = sm.cx + sm.vx * 3;
        const predY = sm.cy + sm.vy * 3;
        paintReflection(el, sm.cx, sm.cy, !hasTilt, predX, predY, sm.hx, sm.hy);
        if (sm.on) sm.raf = requestAnimationFrame(stepSmooth);
      };
      el.addEventListener('pointermove', (e) => {
        el.classList.add('is-glow'); // 悬停点亮高光带（同 harness onMouseMove）
        el.dataset.spotX = String(e.clientX);
        el.dataset.spotY = String(e.clientY);
        if (corners) {
          sm.tx = e.clientX;
          sm.ty = e.clientY;
          if (!sm.on) {
            sm.on = true;
            sm.cx = e.clientX; // 入场直接到位，避免光从远处滑进来
            sm.cy = e.clientY;
            sm.hx = e.clientX;
            sm.hy = e.clientY;
            sm.px = e.clientX;
            sm.py = e.clientY;
            sm.last = performance.now();
            sm.raf = requestAnimationFrame(stepSmooth);
          }
        } else {
          cancelAnimationFrame(raf);
          raf = requestAnimationFrame(() => paintReflection(el, e.clientX, e.clientY, !hasTilt));
        }
      });
      el.addEventListener('pointerleave', () => {
        cancelAnimationFrame(raf);
        sm.on = false;
        cancelAnimationFrame(sm.raf);
        el.classList.remove('is-glow'); // 离开熄灭高光带（同 harness onMouseLeave）
        el.dataset.spotX = '';
        el.dataset.spotY = '';
        el.style.setProperty('--gx', '0px'); // 反光带滑回原位
        if (!hasTilt) {
          el.style.transition = REFLECT_SLOW;
          el.style.transform = '';
        }
      });
    };

    // 小卡片/小版块：文章卡、分类块、联系卡、账号卡、翻页卡、动态卡、资源卡、
    // 友链卡 —— 全部改用「边缘漏光」；番剧卡保留斜向反光带
    document
      .querySelectorAll<HTMLElement>(
        '.article-card, .cat-block, .contact-card, .account-card, .pager-card, .moment-card, .related-item a, .bangumi-card, .resource-card, .friend-card'
      )
      .forEach((el) => {
        if (!el.classList.contains('bangumi-card')) el.classList.add('spot-corners');
        bindOne(el);
      });

    // 面板类只绑定宽度 ≤700px 的小板块（主页个人卡/公告卡/数据卡/最新文章），
    // 大背景板不参与；小面板同样用「边缘漏光」
    document.querySelectorAll<HTMLElement>('.panel').forEach((el) => {
      if (el.getBoundingClientRect().width > 700) return;
      el.classList.add('spot-corners');
      bindOne(el);
    });

    // 留言板的 NOTICE 公告 / STATS 数据 / COMMENTS 评论三个板块：整块参与，不按宽度过滤
    document
      .querySelectorAll<HTMLElement>('.gb-notice, .gb-stats, .comments-panel')
      .forEach((el) => {
        el.classList.add('spot-corners');
        bindOne(el);
      });
  };

  // ---- 悬浮音乐播放器（内存级 Audio：不随 DOM 切换销毁，切板块音乐不断） ----
  const playerIcons = {
    play: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>',
    pause: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M7 5h4v14H7zM13 5h4v14h-4z"/></svg>',
    repeat:
      '<svg viewBox="0 0 24 24" fill="currentColor"><path d="m6.85 19 .85.85q.3.3.288.7t-.288.7q-.3.3-.712.313T5.425 21.3L2.85 18.725q-.15-.15-.212-.325T2.575 18t.063-.375t.212-.325l2.575-2.575q.3-.3.713-.287t.712.312q.275.3.288.7t-.288.7l-.85.85H17v-3q0-.425.288-.712T18 13t.713.288T19 14v3q0 .825-.587 1.413T17 19zm10.3-12H7v3q0 .425-.288.713T6 11t-.712-.288T5 10V7q0-.825.588-1.412T7 5h10.15l-.85-.85q-.3-.3-.287-.712t.312-.713q.3-.275.7-.287t.7.287l2.575 2.575q.15.15.213.325t.062.375t-.062.375t-.213.325L17.425 9.9q-.3.3-.712.288t-.713-.313q-.275-.3-.287-.7t.287-.7z"/></svg>',
    repeatOne:
      '<svg viewBox="0 0 24 24" fill="currentColor"><path d="m6.85 19 .85.85q.3.3.288.7t-.288.7q-.3.3-.712.313T5.425 21.3L2.85 18.725q-.15-.15-.212-.325T2.575 18t.063-.375t.212-.325l2.575-2.575q.3-.3.713-.287t.712.312q.275.3.288.7t-.288.7l-.85.85H17v-3q0-.425.288-.712T18 13t.713.288T19 14v3q0 .825-.587 1.413T17 19zm10.3-12H7v3q0 .425-.288.713T6 11t-.712-.288T5 10V7q0-.825.588-1.412T7 5h10.15l-.85-.85q-.3-.3-.287-.712t.312-.713q.3-.275.7-.287t.7.287l2.575 2.575q.15.15.213.325t.062.375t-.062.375t-.213.325L17.425 9.9q-.3.3-.712.288t-.713-.313q-.275-.3-.287-.7t.287-.7z"/><text x="12" y="16.5" font-size="8" font-weight="700" text-anchor="middle">1</text></svg>',
    shuffle:
      '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M14 4h6v6h-2V7.83l-5.17 5.17-1.41-1.41L16.59 6.4H14zM4 17.17 5.41 18.6l6.17-6.17-1.41-1.41zM20 17.17 18.59 18.6 14 14l1.41-1.41zM4 5.83 5.41 4.4l4.17 4.17-1.41 1.41z"/></svg>',
    volHigh:
      '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M4 9h3l4-4v14l-4-4H4z"/><path d="M15 8.6a4.2 4.2 0 0 1 0 6.8"/><path d="M17.6 6a7.4 7.4 0 0 1 0 12"/></svg>',
    volMute:
      '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M4 9h3l4-4v14l-4-4H4z"/><path d="m15.5 9.2 4.8 4.8m0-4.8-4.8 4.8"/></svg>',
  };

  const playerState = {
    tracks: [] as Array<{ title: string; artist: string; src: string; cover?: string }>,
    index: 0,
    mode: 'list' as 'list' | 'one' | 'shuffle',
    audio: null as HTMLAudioElement | null,
  };

  // 模块级共享音频：new Audio() 不挂在 DOM 上，页面切换（ClientRouter）不会销毁它
  let sharedAudio: HTMLAudioElement | null = null;
  // 用户是否手动点过静音（点过之后不再自动解除静音）
  let userMutedByClick = false;

  // 首次与页面交互：若自动播放被浏览器拦截则补播，并解除静音出声
  const unmuteOnFirstInteraction = () => {
    if (sharedAudio) {
      if (sharedAudio.paused) {
        sharedAudio.play().catch(() => {});
      }
      if (sharedAudio.muted && !userMutedByClick) {
        sharedAudio.muted = false;
        const btn = q('#player-mute');
        if (btn) btn.innerHTML = playerIcons.volHigh;
      }
    }
    document.removeEventListener('pointerdown', unmuteOnFirstInteraction);
    document.removeEventListener('keydown', unmuteOnFirstInteraction);
    document.removeEventListener('touchstart', unmuteOnFirstInteraction);
  };
  document.addEventListener('pointerdown', unmuteOnFirstInteraction);
  document.addEventListener('keydown', unmuteOnFirstInteraction);
  document.addEventListener('touchstart', unmuteOnFirstInteraction);

  const fmtTime = (sec: number) => {
    if (!isFinite(sec)) return '0:00';
    const m = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return `${m}:${String(s).padStart(2, '0')}`;
  };

  const setVol = (v: number) => {
    const audio = playerState.audio;
    if (!audio) return;
    audio.volume = Math.min(1, Math.max(0, v));
    audio.muted = false;
    const fill = q('#player-vol-fill');
    if (fill) fill.style.width = `${audio.volume * 100}%`;
    const muteBtn = q('#player-mute');
    if (muteBtn) muteBtn.innerHTML = audio.volume === 0 ? playerIcons.volMute : playerIcons.volHigh;
    try {
      localStorage.setItem('music-volume', String(audio.volume));
    } catch { /* 忽略 */ }
  };

  // 把当前播放状态同步到（可能刚重建的）弹窗 DOM
  const syncPlayerUI = () => {
    const audio = playerState.audio;
    if (!audio) return;
    const t = playerState.tracks[playerState.index];
    if (t) {
      const titleEl = q('#player-title');
      const artistEl = q('#player-artist');
      if (titleEl) titleEl.textContent = t.title;
      if (artistEl) artistEl.textContent = t.artist;
      const cover = q('#player-cover') as HTMLImageElement | null;
      if (cover) {
        cover.hidden = true;
        cover.onload = () => {
          cover.hidden = false;
        };
        cover.onerror = () => {
          cover.hidden = true;
        };
        cover.src = t.cover ?? '';
      }
    }
    q('#player-disc')?.classList.toggle('is-playing', !audio.paused);
    const toggleBtn = q('#player-toggle');
    if (toggleBtn) {
      toggleBtn.innerHTML = audio.paused ? playerIcons.play : playerIcons.pause;
      toggleBtn.setAttribute('aria-label', audio.paused ? '播放' : '暂停');
    }
    const cur = q('#player-current');
    if (cur) cur.textContent = fmtTime(audio.currentTime);
    const dur = q('#player-duration');
    if (dur) dur.textContent = fmtTime(audio.duration);
    const pct = audio.duration ? (audio.currentTime / audio.duration) * 100 : 0;
    const fill = q('#player-fill');
    if (fill) fill.style.width = `${pct}%`;
    q('#player-track')?.querySelector('.progress-thumb')?.setAttribute('style', `left:${pct}%`);
    const volFill = q('#player-vol-fill');
    if (volFill) volFill.style.width = `${audio.volume * 100}%`;
    const muteBtn = q('#player-mute');
    if (muteBtn) muteBtn.innerHTML = audio.muted || audio.volume === 0 ? playerIcons.volMute : playerIcons.volHigh;
    const repeatBtn = q('#player-repeat');
    if (repeatBtn) {
      repeatBtn.innerHTML =
        playerState.mode === 'list'
          ? playerIcons.repeat
          : playerState.mode === 'one'
            ? playerIcons.repeatOne
            : playerIcons.shuffle;
    }
    const listBtn = q('#player-list');
    if (playerState.tracks.length > 1) listBtn?.removeAttribute('hidden');
    else listBtn?.setAttribute('hidden', '');
    q('#player-playlist')
      ?.querySelectorAll<HTMLElement>('.playlist-item')
      .forEach((it) =>
        it.classList.toggle('is-current', parseInt(it.dataset.index ?? '-1', 10) === playerState.index)
      );
  };

  const loadTrack = (i: number) => {
    const tracks = playerState.tracks;
    const audio = playerState.audio;
    if (tracks.length === 0 || !audio) return;
    playerState.index = ((i % tracks.length) + tracks.length) % tracks.length;
    const t = tracks[playerState.index];
    audio.src = t.src;
    audio.play().catch(() => {});
    syncPlayerUI();
  };

  const bindPlayer = () => {
    const pop = q('#music-popup');
    if (!pop) return;
    playerState.tracks = JSON.parse(pop.dataset.tracks ?? '[]');

    // 创建一次共享音频（内存对象，页面切换不销毁）
    if (!sharedAudio) {
      sharedAudio = new Audio();
      sharedAudio.preload = 'metadata';
      let savedVol = 0.7;
      try {
        savedVol = parseFloat(localStorage.getItem('music-volume') ?? '0.7');
      } catch { /* 忽略 */ }
      if (isNaN(savedVol)) savedVol = 0.7;
      sharedAudio.volume = savedVol;

      sharedAudio.addEventListener('play', () => {
        q('#player-disc')?.classList.add('is-playing');
        const btn = q('#player-toggle');
        if (btn) {
          btn.innerHTML = playerIcons.pause;
          btn.setAttribute('aria-label', '暂停');
        }
        const mb = q('#player-mute');
        if (mb) mb.innerHTML = sharedAudio!.muted || sharedAudio!.volume === 0 ? playerIcons.volMute : playerIcons.volHigh;
      });
      sharedAudio.addEventListener('pause', () => {
        q('#player-disc')?.classList.remove('is-playing');
        const btn = q('#player-toggle');
        if (btn) {
          btn.innerHTML = playerIcons.play;
          btn.setAttribute('aria-label', '播放');
        }
      });
      sharedAudio.addEventListener('timeupdate', () => {
        const pct = sharedAudio!.duration ? (sharedAudio!.currentTime / sharedAudio!.duration) * 100 : 0;
        const fill = q('#player-fill');
        if (fill) fill.style.width = `${pct}%`;
        q('#player-track')?.querySelector('.progress-thumb')?.setAttribute('style', `left:${pct}%`);
        const cur = q('#player-current');
        if (cur) cur.textContent = fmtTime(sharedAudio!.currentTime);
      });
      sharedAudio.addEventListener('loadedmetadata', () => {
        const dur = q('#player-duration');
        if (dur) dur.textContent = fmtTime(sharedAudio!.duration);
      });
      sharedAudio.addEventListener('ended', () => {
        if (playerState.mode === 'one') {
          sharedAudio!.currentTime = 0;
          sharedAudio!.play().catch(() => {});
        } else if (playerState.tracks.length > 1) {
          loadTrack(playerState.index + 1);
        } else {
          sharedAudio!.currentTime = 0;
          sharedAudio!.pause();
        }
      });
    }
    playerState.audio = sharedAudio;

    // 首次加载（无 src 时）：静音自动播放（浏览器允许），
    // 用户第一次与页面交互时自动解除静音；或同步现有状态到新 DOM
    if (!sharedAudio.src) {
      sharedAudio.muted = true; // 静音自动播放
      loadTrack(0);
    } else {
      syncPlayerUI();
    }
  };

  // ---- 全局 Toast 轻提示（页面脚本通过 window.showToast(msg, type) 调用） ----
  (window as unknown as { showToast?: (msg: string, type?: 'ok' | 'err') => void }).showToast = (
    msg: string,
    type: 'ok' | 'err' = 'ok'
  ) => {
    const host = q('#toast-host');
    if (!host) return;
    const t = document.createElement('div');
    t.className = 'toast' + (type === 'err' ? ' is-err' : '');
    if (type === 'ok') {
      // 成功提示：画出来的动画对号 + 文本
      t.innerHTML =
        '<svg class="copy-check" viewBox="0 0 24 24" aria-hidden="true">' +
        '<circle class="check-circle" cx="12" cy="12" r="10" />' +
        '<path class="check-path" d="M7.5 12.5l3 3 6-6" />' +
        '</svg><span class="toast-text"></span>';
      (t.querySelector('.toast-text') as HTMLElement).textContent = msg;
    } else {
      t.textContent = msg;
    }
    host.appendChild(t);
    requestAnimationFrame(() => t.classList.add('is-in'));
    window.setTimeout(() => {
      t.classList.remove('is-in');
      t.addEventListener('transitionend', () => t.remove(), { once: true });
      window.setTimeout(() => t.remove(), 450); // 兜底移除
    }, 2400);
  };

  const init = () => {
    // 页面切换（ClientRouter）会覆盖 <html> 属性，这里每次导航后从 localStorage 恢复主题
    try {
      const saved = localStorage.getItem('blog-theme');
      if (saved) document.documentElement.dataset.theme = saved;
    } catch {
      /* 忽略 */
    }
    syncScroll();
    syncThemeIcon();
    observeReveals();
    bindTilt();
    bindPanelReflection();
    bindSpy();
    bindPlayer();
    // 关闭搜索面板（导航到新页面后）
    q('#search-panel')?.classList.remove('open');
  };
  init();
  document.addEventListener('astro:page-load', init);
    